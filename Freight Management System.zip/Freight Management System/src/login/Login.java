package login;

import java.io.*;
import java.util.List;
import java.util.Scanner;
import java.lang.String;

import Data.CheckAllData;
import Data.ClientPasswordD;
import Data.CustomerPasswordD;

import Exiting.Exit;
import Menu.Mainemenu;

import static Menu.Mainemenu.ClientMenu;
import static Menu.Mainemenu.CustomerMenu;
import static java.lang.System.in;

public class Login extends CheckAllData implements Serializable{

    public static void checkInput(){
        Scanner input = new Scanner(in);
        System.out.println("<-----Freight Management System----->");
        System.out.println("[1]Login \n[0]Exit");
        String key;
        key = input.nextLine();
        switch (key) {
            case "1":
                checkUser();
                break;
            case "0":
                Exit exit = new Exit();
                exit.exiting();
                break;
        }
        if (!key.equals(1) || !key.equals(2)) {
            checkInput();
        }
    }

    public static void checkUser(){
        Scanner input = new Scanner(in);
        System.out.println("[1]Admin \n[2]Customers \n[3]Clients \n[4]Exit");
        String key;
        key = input.nextLine();
        switch (key) {
            case "1":
                Admin();
                break;
            case "2":
                Customer(customerPasswordDArrayList);
                break;
            case "3":
                Client(clientPasswordDArrayList);
                break;
            case "4":
                Exit exit = new Exit();
                exit.exiting();
                break;
        }
        if (!key.equals(1) ||
                !key.equals(2) ||
                !key.equals(3)) {
            checkInput();
        }
    }

    private static void Client(List<ClientPasswordD> list) {
        try {
            setReader();
            {
                System.out.print("-->>Username: ");
                String user = reader.readLine();

                System.out.print("-->>Password: ");
                String pass = reader.readLine();

                while (clientsLogPass.canRead()){
                    for (ClientPasswordD CPD : list) {
                        if (user.equals(CPD.getClientlog()) && pass.equals(CPD.getClientpass())) {
                            ClientMenu(shippingCompaniesDArrayList,CPD.getClientID());
                        }else if(!user.equals(CPD.getClientlog()) && !pass.equals(CPD.getClientpass())){
                            System.err.println("________----Error----________\n press 'Enter' to continue...");
                            reader.readLine();
                            checkInput();
                        }
                    }
                    break;
                }
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    public static void Customer(List<CustomerPasswordD> list) {
            try {
                setReader();
                {
                    System.out.print("-->>Username: ");
                    String user = reader.readLine();

                    System.out.print("-->>Password: ");
                    String pass = reader.readLine();

                    while (customerLogPass.canRead()){
                        for (CustomerPasswordD cpd : list) {
                            if (user.equals(cpd.getCustomerlog()) && pass.equals(cpd.getCustomerpass()) ) {
                                CustomerMenu(customerManagementDArraysList,cpd.getCustomerID());
                            }else if(!user.equals(cpd.getCustomerlog()) && !pass.equals(cpd.getCustomerpass()) ){
                                System.err.println("________----Error----________\n press 'Enter' to continue...");
                                reader.readLine();
                                checkInput();
                            }
                        }
                        break;
                    }
                }

            } catch (IOException e) {
                e.printStackTrace();
            }
        }

    private static void Admin() {

        String record = null;
        FileReader in = null;
        try {
            BufferedReader br = new BufferedReader(new FileReader("AdminLogPass.txt"));

            System.out.print("Username: ");
            String user = reader.readLine();

            System.out.print("Password: ");
            String pass = reader.readLine();

            Mainemenu menu = null;
            while ((record = br.readLine()) !=null) {

                // Split line by a whitespace character
                // split[0] <- username
                // split[1] <- password
                String[] split = record.split("\\s");

                if (user.equals(split[0]) && pass.equals(split[1])) {
                    menu = new Mainemenu();
                    menu.AdminMenu();

                    // You found the user, exit the loop
                    break;
                }
                // Delete else branch
            }
            if (menu == null) {
                System.err.println("________----Error----________\n press 'Enter' to continue...");
                reader.readLine();
                checkInput();
            }
        } catch (IOException e) {
            e.getCause();
        }
    }
}


