package Menu;

import Data.CheckAllData;
import Data.ClientPasswordD;
import Data.LeasingD;
import Data.ShippingCompaniesD;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

import static Menu.AdminAndClientManagement.InputDataClient;
import static Menu.AdminAndClientManagement.Switch;

/**
 * Created by Bogdan
 */
public class ClientManagement extends LeasingService {
    public static void ViewClientLogAndPass(List<ClientPasswordD> list) {
        try {
            setReader();
            {
                System.out.println("-->>Client ID: ");
                String clientID = reader.readLine();
                while (clientsLogPass.canRead()) {
                    for (ClientPasswordD cpd : list) {
                        if (clientID.equals(cpd.getClientID())) {
                            System.out.println("|- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -|");
                            System.out.println(cpd.toString());
                            System.err.println("Press 'Enter' to continue...");
                            String absentinput = reader.readLine();
                        }
                    }
                    break;
                }
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void ViewClients(ArrayList<ShippingCompaniesD> list) {
        {
            while (clients.canRead()) {
                Collections.sort(list);
                for (ShippingCompaniesD scd : list) {
                    System.out.println("|- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -|");
                    System.out.println(scd.toString());
                }
                break;
            }
        }
    }

    public static void ViewCompany(List<ShippingCompaniesD> list) {
        try {
            setReader();
            {
                System.out.println("-->>Customer ID: ");
                String custID = reader.readLine();
                while (clients.canRead()) {
                    Collections.sort(list);
                    for (ShippingCompaniesD SCD : list) {
                        if (custID.equals(SCD.getCompanyID())) {
                            System.out.println("|- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -|");
                            System.out.println(SCD.toString());
                        }
                    }
                    break;
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public static void checkleasing(List<LeasingD> list) {
        try {
            setReader();
            {
                System.out.println("-->>Client ID: ");
                String clientID = reader.readLine();
                while (leasing.canRead()) {
                    Collections.sort(list);
                    for (LeasingD SCD : list) {
                        if (clientID.equals(SCD.getCompanyID())) {
                            System.out.println("|- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -|");
                            System.out.println(SCD.toString());
                        }
                    }
                    break;
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

    }
    public static void setDeleteClient(String clientID) {
        //[Iterator]Fail Safe means: it won't fail. Strictly speaking,
        // there is no such thing in Java as a fail-safe iterator.
        // The correct term is "weakly consistent".
        Iterator itr = shippingCompaniesDArrayList.iterator();
        while (itr.hasNext()) {
            ShippingCompaniesD element = (ShippingCompaniesD) itr.next();
            if (element.getCompanyID().equals(clientID)) {
                itr.remove();
                break;
            }
        }
    }

    public static void setDeleteClientLogPass(String clientID) {
        Iterator itr1 = clientPasswordDArrayList.iterator();
        while (itr1.hasNext()) {
            ClientPasswordD element1 = (ClientPasswordD) itr1.next();
            if (element1.getClientID().equals(clientID)) {
                itr1.remove();
                break;
            }
        }
    }

    public static void setDeleteClientLeasing(String clientID) {
        Iterator itr3 = leasingDArrayList.iterator();
        while (itr3.hasNext()) {
            LeasingD element1 = (LeasingD) itr3.next();
            if (element1.getCompanyID().equals(clientID)) {
                itr3.remove();
                break;
            }
        }
    }
}
class LeasingService extends CheckAllData {
    //Count Contract Hire leasing
    public static void ContractHire(int finalprice,String Ship,String companyName, String companyemail,String contactNo) {
        int countprice = (finalprice / 100) * 10;
        finalprice = finalprice + countprice;
        String typeofleasing = "Contract Hire";
        System.err.println(" ");
        System.err.println("==>>Final Price: Rm" + finalprice + "\n");
        WriteClient(shippingCompaniesDArrayList, companyName, companyemail, contactNo, Ship, typeofleasing, finalprice);
    }
    //Count Operating Leasing
    public static void OperatingLeasing(int finalprice,String Ship,String companyName, String companyemail,String contactNo) {
        int countprice = (finalprice / 100) * 40;
        finalprice = finalprice + countprice;
        String typeofleasing = "Operating Leasing";
        System.err.println(" ");
        System.err.println("==>>Final Price: Rm" + finalprice + "\n");
        WriteClient(shippingCompaniesDArrayList, companyName, companyemail, contactNo, Ship, typeofleasing, finalprice);
    }
    //Check login, to avoid duplication
    public static void checkClientLogAndPass(List<ClientPasswordD> list, String login1) {
        setReader();
        {
            while (clientsLogPass.canRead()) {
                for (ClientPasswordD cpd : list) {
                    if (login1.equals(cpd.getClientpass())) {
                        System.err.println("");
                        System.err.println("<===This login already taken===>");
                        System.err.print("");
                        InputDataClient();
                    }
                }
                break;
            }
        }
    }

    public static void WritePassLog(List<ClientPasswordD> list1, String login1, String password1) {
        clientPasswordDArrayList.add(new ClientPasswordD(login1, password1, clientID));
        ObjectOutputStream outStream = null;
        try {
            outStream = new ObjectOutputStream(new FileOutputStream(clientsLogPass));
            for (ClientPasswordD p1 : list1) {
                outStream.writeObject(p1);
            }
        } catch (IOException ioException) {
            System.err.println("Error opening file.");
        } finally {
            try {
                if (outStream != null) outStream.close();
            } catch (IOException ioException) {
                ioException.getMessage();
            }
        }
    }

    public static void WriteClient(List<ShippingCompaniesD> list, String companyName, String companyemail, String contactNo, String typeofship, String typeofleasing ,int finalprice) {
        System.out.println("[1] Save: \n" + "[2] Cancel: ");
        try {
            String finalcheck = reader.readLine();

            if (finalcheck.equals("1")) {
                System.out.println("-->>Login for Client: ");
                String login1 = reader.readLine();

                System.out.println("-->>Password for Client: ");
                String password1 = reader.readLine();

                if(login1.isEmpty() || password1.isEmpty()){
                    System.out.println("|=====Error=====|\n Press 'Enter' to continue...");
                    String absent_input = reader.readLine();
                    Switch();
                }

                checkClientLogAndPass(clientPasswordDArrayList, login1);
                WritePassLog(clientPasswordDArrayList, login1, password1);

            } else if (finalcheck.equals("2") || finalcheck.isEmpty()) {
                Switch();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        shippingCompaniesDArrayList.add(new ShippingCompaniesD(clientID, companyName, companyemail, contactNo,typeofship));
        WriteLeasing(leasingDArrayList,clientID,companyName,typeofleasing,finalprice);
        ObjectOutputStream outStream = null;
        try {
            outStream = new ObjectOutputStream(new FileOutputStream(clients));
            for (ShippingCompaniesD p : list) {
                outStream.writeObject(p);
            }
        } catch (IOException ioException) {
            System.err.println("Error opening clients file.");
        } finally {
            try {
                if (outStream != null) outStream.close();
                System.err.println("|______Client was successfully saved______|\n   Press 'Enter' to continue...");
                String absentinput = reader.readLine();
                Switch();
            } catch (IOException ioException) {
                System.err.println("Error closing file.");
            }
        }
    }
    public static void WriteLeasing(List<LeasingD> list1, String clientID,String companyName,String typeofleasing, int finalprice) {

        leasingDArrayList.add(new LeasingD(clientID,companyName,typeofleasing,finalprice));

        ObjectOutputStream outStream = null;
        try {
            outStream = new ObjectOutputStream(new FileOutputStream(leasing));
            for (LeasingD p2 : list1) {
                outStream.writeObject(p2);
            }
        } catch (IOException ioException) {
            System.err.println("Error opening leasing file.");
        } finally {
            try {
                if (outStream != null) outStream.close();
            } catch (IOException ioException) {
                ioException.getMessage();
            }
        }
    }

}