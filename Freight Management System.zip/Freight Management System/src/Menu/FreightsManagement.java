package Menu;

import Data.BookingD;
import Data.CustomerManagementD;
import Data.RoutesD;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.*;

/**
 * Created by Bogdan
 */
public class FreightsManagement extends RoutesManagement {

    private static int price_of_first_port;
    private static int price_of_first_port1;
    private static int price_of_first_port2;
    private static int price_of_second_port;
    private static String name_of_first_port;
    private static String name_of_first_port1;
    private static String name_of_second_port;
    private static String type_of_cargo;

    public static void Admin_And_Client_Switch(String custID) {
        System.out.println("\n|______Freights Management______|\n" + "[1] Add Booking \n" + "[2] Delete Booking \n" + "[3] View all Booking \n" + "[4] Back to main menu \n");
        String input = null;
        try {
            input = reader.readLine();
        } catch (IOException e) {
            e.printStackTrace();
        }
        switch (input) {
            case "1":
                Create_Booking(routesDArrayList, custID);
                break;
            case "2":
                Delete_Booking(bookingDArrayList);
                break;
            case "3":
                View_Booking(bookingDArrayList);
                break;
            case "4":
                Mainemenu.AdminMenu();
                break;
        }
        if (!input.equals(1) || !input.equals(2) || !input.equals(3) || !input.equals(4) || !input.equals(5)) {
            Admin_And_Client_Switch(custID);
        }
    }

    public static void Client_Switch() {
        System.out.println("\n|______Freights Management______|\n" + "[1]View all Booking \n" + "[2] Back to main menu \n");
        String input = null;
        try {
            input = reader.readLine();
        } catch (IOException e) {
            e.printStackTrace();
        }
        switch (input) {
            case "1":
                View_Booking(bookingDArrayList);
                break;
            case "2":
                Mainemenu.AdminMenu();
                break;
        }
        if (!input.equals(1) || !input.equals(2)) {
            Client_Switch();
        }
    }

    private static void Create_Booking(List<RoutesD> list, String custID) {
        setReader();
        {
            System.out.println("|______Register booking:______|\n");
            Fixed_routes();
            while (routes.canRead()) {
                for (RoutesD RD : list) {
                    System.out.println(RD.toString());
                }
                Count_routes(routesDArrayList, routesDArrayList1, price_of_first_port, price_of_first_port1, price_of_second_port, name_of_first_port, name_of_first_port1, name_of_second_port, custID,price_of_first_port2);
                break;
            }
        }
    }

    private static void Count_routes(List<RoutesD> list, Set<RoutesD> list1, int price_of_first_port, int price_of_second_port, int price_of_first_port1, String name_of_first_port, String name_of_first_port1, String name_of_second_port, String custID,int price_of_first_port2) {
        try {
            System.out.println("\n-->>First Port ID: ");
            String RID = reader.readLine();
            int roudeID = Integer.parseInt(RID);

            System.out.println("\n-->>Second Port ID: ");
            String RID2 = reader.readLine();
            int roudeID2 = Integer.parseInt(RID2);
            for (RoutesD RD1 : list1) {
                if (roudeID == RD1.getPortID()) {
                    System.out.println(RD1.toString());
                    price_of_first_port = RD1.getPrice();
                    name_of_first_port = RD1.getNameOfport();
                }
            }
            for (RoutesD RD2 : list1) {
                if (roudeID2 == RD2.getPortID()) {
                    System.out.println(RD2.toString());
                    price_of_second_port = RD2.getPrice();
                    name_of_second_port = RD2.getNameOfport();
                }
            }
            while (fixed_routes.canRead()) {
                for (RoutesD RD3 : list) {
                    if (roudeID == RD3.getPortID()) {
                        System.out.println(RD3.toString());
                        price_of_first_port1 = RD3.getPrice();
                        name_of_first_port = RD3.getNameOfport();
                    }
                }
                break;
            }
            while (fixed_routes.canRead()) {
                for (RoutesD RD4 : list) {
                    if (roudeID2 == RD4.getPortID()) {
                        System.out.println(RD4.toString());
                        price_of_first_port2 = RD4.getPrice();
                        name_of_second_port = RD4.getNameOfport();
                    }
                }
                break;
            }
            int total_price = price_of_first_port + price_of_second_port + price_of_first_port1 + price_of_first_port2;

            System.out.println("Price of route " + total_price);

            cargo(total_price, name_of_first_port, name_of_second_port, type_of_cargo, custID);

        } catch (IOException e) {
            e.printStackTrace();
            Admin_And_Client_Switch(custID);
        } catch (NumberFormatException ex) {
            Admin_And_Client_Switch(custID);
        }
    }

    private static void cargo(int total_price, String name_of_first_port, String name_of_second_port, String type_of_cargo, String custID) {
        try {
            System.out.println("\n-->>Enter cargo weight: ");
            String weight = reader.readLine();
            int weight_cargo = Integer.parseInt(weight);
            if (50 <= weight_cargo && weight_cargo < 7000) {
                type_of_cargo = "Less than truckload (LTL) price up 20% ";
                total_price = weight_cargo * 20;

            } else if (7000 <= weight_cargo && weight_cargo <= 100000) {
                type_of_cargo = "Truckload freight (TL) price up 30%";
                total_price = weight_cargo * 30;

            } else if (weight_cargo < 50) {
                System.out.println("|-=-=-==-=-=-Weight of cargo to low-=-=-=-=-=-=-=|\n |-=-=-==-=-=-Press 'Enter' to continue...-=-=-=-=-=-=-=|");
                String absent_input = reader.readLine();
                cargo(total_price, name_of_first_port, name_of_second_port, type_of_cargo, custID);

            } else if (weight_cargo > 100000) {
                System.out.println("|-=-=-==-=-=-Weight of cargo to high-=-=-=-=-=-=-=|\n |-=-=-==-=-=-Press 'Enter' to continue...-=-=-=-=-=-=-=|");
                String absent_input = reader.readLine();
                cargo(total_price, name_of_first_port, name_of_second_port, type_of_cargo, custID);
            }
            System.out.println("TOTAL PRICE: RM" + total_price + " TYPE OF CARGO: " + type_of_cargo + "\nDo you want to continue?\n[1]Yes [2]No");
            String input = reader.readLine();

            switch (input) {
                case "1":
                    Write_Booking(bookingDArrayList, customerManagementDArraysList, type_of_cargo, total_price, name_of_first_port, name_of_second_port, custID);
                    break;
                case "2":
                    Admin_And_Client_Switch(custID);
                    break;
            }
        } catch (IOException e) {
            e.getMessage();
            Admin_And_Client_Switch(custID);
        }
    }

    private static void Write_Booking(List<BookingD> list, List<CustomerManagementD> list1, String type_of_cargo, int total_price, String name_of_first_port, String name_of_second_port, String custID) {
        if (custID != null) {
            while (customers.canRead()) {
                for (CustomerManagementD cpd : list1) {
                    if (custID.equals(cpd.getCustomerID())) {
                        custID = cpd.getCustomerID();
                    }
                }
                break;
            }
        }
        // Instantiate a Date object
        Date date = new Date();
        ObjectOutputStream outStream = null;
        try {
            while (booking.canRead()) {
                for (BookingD bookingD : bookingDArrayList) {
                    bookingID = bookingD.getBookingID();
                    if (bookingID <= 0 || bookingID > 0) {
                        bookingID++;
                    }
                }
                break;
            }
            bookingDArrayList.add(new BookingD(bookingID, custID, date.toString(), type_of_cargo, name_of_first_port, name_of_second_port, total_price));
            outStream = new ObjectOutputStream(new FileOutputStream(booking));
            for (BookingD p1 : list) {
                outStream.writeObject(p1);
            }
        } catch (IOException ioException) {
            System.err.println("Error opening file.");
        } finally {
            try {
                if (outStream != null) outStream.close();
                System.err.println("|______Booking was successfully saved______|\n");
            } catch (IOException ioException) {
                ioException.getMessage();
            }
        }
    }

    private static void View_Booking(List<BookingD> list) {
        while (booking.canRead()) {
            for (BookingD bookingD : list) {
                System.out.println("|- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -|");
                System.out.println(bookingD.toString());
            }
            break;
        }
    }

    private static void Delete_Booking(List<BookingD> list) {
        try {
            setReader();
            {
                System.out.println("-->>Booking ID: ");
                String BookingID = reader.readLine();
                int bookingID = Integer.parseInt(BookingID);
                while (routes.canRead()) {
                    for (BookingD BKdelete : list) {
                        if (bookingID == BKdelete.getBookingID()) {
                            System.out.println("\nYou want to delete ? " + "\n" + BKdelete.toString() + "\n" + "[1] Yes [2] No\n");
                            String deleteclient = reader.readLine();
                            if (deleteclient.equals("1")) {
                                System.out.println("");

                                setDeleteBooking(bookingID);

                                System.err.println("|______Booking was successfully deleted______|\n  " + " Press 'Enter' to continue...");
                                String absentinput = reader.readLine();
                                Switch();


                                System.err.println("Booking was deleted!\n" + "Press 'Enter' to continue...");
                                String deleteclient1 = reader.readLine();
                                Switch();
                            } else if (deleteclient.equals("2")) {
                                Switch();
                            }
                        }
                    }
                    break;
                }
                System.err.println("|=|=|=|=|=|=Route was not found=|=|=|=|=|=|" + "\n" + "\n");
            }
        } catch (IOException e) {
            e.getMessage();
        }
    }

    public static void setDeleteBooking(int deleteBooking) {
        //[Iterator]Fail Safe means: it won't fail. Strictly speaking,
        // there is no such thing in Java as a fail-safe iterator.
        // The correct term is "weakly consistent".
        Iterator itr = routesDArrayList.iterator();
        while (itr.hasNext()) {
            RoutesD element = (RoutesD) itr.next();
            if (element.getPortID() == deleteBooking) {
                itr.remove();
                break;
            }
        }
    }
}
