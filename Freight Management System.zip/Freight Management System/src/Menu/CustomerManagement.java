package Menu;

import Data.CheckAllData;
import Data.CustomerManagementD;
import Data.CustomerPasswordD;

import java.io.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

/**
 * Created by Bogdan
 */
public class CustomerManagement extends CheckAllData{
    public static void ViewCustomers(ArrayList<CustomerManagementD> list) {
        {
            while (customers.canRead()) {
                Collections.sort(list);
                for (CustomerManagementD cmd : list) {
                    System.out.println("|- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -|");
                    System.out.println(cmd.toString());
                }
                break;
            }
        }
    }

    public static void WritePassLog(List<CustomerPasswordD> list1, String login1, String password1) {
        customerPasswordDArrayList.add(new CustomerPasswordD(login1, password1, customerID));
        ObjectOutputStream outStream = null;
        try {
            outStream = new ObjectOutputStream(new FileOutputStream(customerLogPass));
            for (CustomerPasswordD p1 : list1) {
                outStream.writeObject(p1);
            }
        } catch (IOException ioException) {
            System.err.println("Error opening file.");
        } finally {
            try {
                if (outStream != null) outStream.close();
            } catch (IOException ioException) {
                ioException.getMessage();
            }
        }
    }
    public static void ViewCustomer(List<CustomerManagementD> list) {
        try {
            setReader();
            {
                System.out.println("-->>Customer ID: ");
                String custID = reader.readLine();
                while (customers.canRead()) {
                    Collections.sort(list);
                    for (CustomerManagementD cmd : list) {
                        if (custID.equals(cmd.getCustomerID())) {
                            System.out.println("|- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -|");
                            System.out.println(cmd.toString());
                        }
                    }
                    break;
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void setDeleteCustomer(String custID) {
        //[Iterator]Fail Safe means: it won't fail. Strictly speaking,
        // there is no such thing in Java as a fail-safe iterator.
        // The correct term is "weakly consistent".
        Iterator itr = customerManagementDArraysList.iterator();
        while (itr.hasNext()) {
            CustomerManagementD element = (CustomerManagementD) itr.next();
            if (element.getCustomerID().equals(custID)) {
                itr.remove();
                break;
            }
        }
    }

    public static void setDeleteLogPass(String custID) {
        Iterator itr1 = customerPasswordDArrayList.iterator();
        while (itr1.hasNext()) {
            CustomerPasswordD element1 = (CustomerPasswordD) itr1.next();
            if (element1.getCustomerID().equals(custID)) {
                itr1.remove();
                break;
            }
        }
    }
    public static void ViewCustomerLogAndPass(List<CustomerPasswordD> list) {
        try {
            CheckAllData.setReader();
            {
                System.out.println("-->>Customer ID: ");
                String custID = reader.readLine();
                while (customerLogPass.canRead()) {
                    for (CustomerPasswordD cpd : list) {
                        if (custID.equals(cpd.getCustomerID())) {
                            System.out.println("|- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -|");
                            System.out.println(cpd.toString());
                            System.err.println("Press 'Enter' to continue...");
                            String absentinput = reader.readLine();
                        }
                    }
                    break;
                }
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
