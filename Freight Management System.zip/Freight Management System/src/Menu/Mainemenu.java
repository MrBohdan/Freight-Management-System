package Menu;

import Data.CheckAllData;
import Data.CustomerManagementD;
import Data.ShippingCompaniesD;
import Exiting.Exit;
import Main.FreightManagementSystem;
import static Data.CheckAllData.*;
import static Menu.ClientManagement.ViewClients;
import static Menu.ClientManagement.ViewCompany;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.List;


/**
 * Created by Bogdan
 */
public class Mainemenu extends CheckAllData{
    private static BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
    public static void AdminMenu() {

        System.out.println("|______Administration Module______|\n" + "[1] Client Management \n" + "[2] Customer Management \n" + "[3] Routes Management \n" + "[4] Freights Management \n" + "[5] Log-out \n" + "[6] Exiting ");
        String input = null;
        try {
            input = reader.readLine();
        } catch (IOException e) {
            e.printStackTrace();
        }
        switch (input) {
            case "1":
                AdminAndClientManagement.Switch();
                break;
            case "2":
                SwitchCustomerManagement.Switch();
                break;
            case "3":
                RoutesManagement.Switch();
                break;
            case "4":
                String custID = null;
                FreightsManagement.Admin_And_Client_Switch(custID);
                break;
            case "5":
                FreightManagementSystem freightManagementSystem = new FreightManagementSystem();
                // TO come back to Main
                String[] arguments = new String[]{};
                freightManagementSystem.main(arguments);
                break;
            case "6":
                Exit exit = new Exit();
                exit.exiting();
                break;
        }
        if (!input.equals(1) || !input.equals(2) || !input.equals(3) || !input.equals(4) || !input.equals(5) || !input.equals(6)) {
            AdminMenu();
        }
        try {
            reader.close();
        } catch (IOException e) {
            e.getMessage();
        }

    }
    public static void ClientMenu(List<ShippingCompaniesD> list, String clientID) {
        System.out.println("|______Client Module______|");
        try {
            setReader();
            {
                while (clients.canRead()) {
                    for (ShippingCompaniesD scd: list) {
                        if (clientID.equals(scd.getCompanyID())) {
                            System.out.println("[" + "Your ID: " + scd.getCompanyID() + " Company name: " + scd.getCompanyEmail() +"]");
                        }
                    }
                    break;
                }
            }
        } finally {

            System.out.println("\n"+"[1] Client Management \n" + "[2] View Customers \n"+ "[3] Search Customer \n" + "[4] Freights Management \n" + "[5] Log-out \n" + "[6] Exiting ");
            String input = null;
            try {
                input = reader.readLine();
            } catch (IOException e) {
                e.printStackTrace();
            }
            switch (input) {
                case "1":
                    AdminAndClientManagement.Switch();
                    break;
                case "2":
                    SwitchCustomerManagement.ViewCustomers(customerManagementDArraysList);
                    break;
                case "3":
                    CustomerManagement.ViewCustomer(customerManagementDArraysList);
                    break;
                case "4":
                    FreightsManagement.Client_Switch();
                    break;
                case "5":
                    FreightManagementSystem freightManagementSystem = new FreightManagementSystem();
                    String[] arguments = new String[]{};
                    freightManagementSystem.main(arguments);
                    break;
                case "6":
                    Exit exit = new Exit();
                    exit.exiting();
                    break;
            }
            if (!input.equals(1) || !input.equals(2) || !input.equals(3) || !input.equals(4) || !input.equals(5)) {
                ClientMenu(shippingCompaniesDArrayList, clientID);
            }
            try {
                reader.close();
            } catch (IOException e) {
                e.getMessage();
            }
        }
    }
    public static void CustomerMenu(List<CustomerManagementD> list, String custID){
        System.out.println("|______Customer Module______|");
        try {
            setReader();
            {
                while (customers.canRead()){
                    for (CustomerManagementD cpd : list) {
                        if (custID.equals(cpd.getCustomerID())) {
                            System.out.println("["+"Your ID: "+ cpd.getCustomerID() + " First name: "+cpd.getFirstName() + " Lst name: " + cpd.getLastName()+"]");
                        }
                    }
                    break;
                }
            }

        }finally {
            System.out.println("[1] Client Management \n" +
                    "[2] Customer Entry \n" +
                    "[3] Freights Management \n"+
                    "[4] Log-out \n"+
                    "[5] Exiting ");
            String input = null;
            try {
                input = reader.readLine();
            } catch (IOException e) {
                e.printStackTrace();
            }
            switch (input) {
                case "1":
                    CustomersToClientManagement(customerManagementDArraysList,custID);
                    break;
                case "2":
                    SwitchCustomerManagement.Switch();
                    break;
                case "3":
                    FreightsManagement.Admin_And_Client_Switch(custID);
                    break;
                case "4":
                    FreightManagementSystem freightManagementSystem = new FreightManagementSystem();
                    String[] arguments = new String[]{};
                    freightManagementSystem.main(arguments);
                    break;
                case "5":
                    Exit exit = new Exit();
                    exit.exiting();
                    break;
            }
            if (!input.equals(1) ||
                    !input.equals(2) ||
                    !input.equals(3) ||
                    !input.equals(4)){
                CustomerMenu(customerManagementDArraysList,custID);
            }
            try{
                reader.close();
            }catch (IOException e){
                e.getMessage();
            }
        }
        }
    public static void CustomersToClientManagement(List<CustomerManagementD> list, String custID){
        System.out.println("|______Customer Module______|");
        try {
            setReader();
            {
                while (customers.canRead()){
                    for (CustomerManagementD cpd : list) {
                        if (custID.equals(cpd.getCustomerID())) {
                            System.out.println("["+"Your ID: "+ cpd.getCustomerID() + " First name: "+cpd.getFirstName() + " Lst name: " + cpd.getLastName()+"]");
                        }
                    }
                    break;
                }
            }

        }finally {
            System.out.println("[1] View Shipping Companies \n" +
                    "[2] Search Shipping Companies \n" +
                    "[3] Log-out \n"+
                    "[4] Exiting ");
            String input = null;
            try {
                input = reader.readLine();
            } catch (IOException e) {
                e.printStackTrace();
            }
            switch (input) {
                case "1":
                    ViewClients(shippingCompaniesDArrayList);
                    break;
                case "2":
                    ViewCompany(shippingCompaniesDArrayList);
                    break;
                case "3":
                    FreightManagementSystem freightManagementSystem = new FreightManagementSystem();
                    String[] arguments = new String[]{};
                    freightManagementSystem.main(arguments);
                    break;
                case "4":
                    Exit exit = new Exit();
                    exit.exiting();
                    break;
            }
            if (!input.equals(1) ||
                    !input.equals(2) ||
                    !input.equals(3) ||
                    !input.equals(4)){
                CustomerMenu(customerManagementDArraysList,custID);
            }
            try{
                reader.close();
            }catch (IOException e){
                e.getMessage();
            }
        }
    }

}

