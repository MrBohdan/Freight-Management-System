package Menu;
/**
 * Created by Bogdan
 */
import Data.CustomerManagementD;
import Data.CustomerPasswordD;
import Data.CheckAllData;
import java.io.*;

import java.io.Serializable;
import java.io.FileOutputStream;
import java.io.ObjectOutputStream;
import java.util.List;

public class SwitchCustomerManagement extends CustomerManagement implements Serializable {

    public static void Switch() {
        CheckAllData.setReader();
        System.out.println("|______Customer Management______|\n" + "[1] Register customer \n" + "[2] Delete customer \n" + "[3] Edit customer\n" + "[4] View customer \n" + "[5] View all customers \n" + "[6] View customers login's and passwords \n" + "[7] Back to main menu \n");
        String input = null;
        try {
            input = reader.readLine();
        } catch (IOException e) {
            e.printStackTrace();
        }
        switch (input) {
            case "1":
                /**
                 * Read ID from file and increment it
                 */
                while (customers.canRead()) {
                    for (CustomerManagementD cmd : customerManagementDArraysList) {
                        cusID = Integer.parseInt(cmd.getCustomerID());
                        if (cusID <= 0 || cusID > 0) {
                            cusID++;
                        }
                    }
                    break;
                }
                customerID = Integer.toString(cusID);
                WriteCustomers();
                break;
            case "2":
                DeleteCustomer(customerManagementDArraysList);
                break;
            case "3":
                EditCustomer(customerManagementDArraysList);
                break;
            case "4":
                ViewCustomer(customerManagementDArraysList);
                break;
            case "5":
                ViewCustomers(customerManagementDArraysList);
                break;
            case "6":
                ViewCustomerLogAndPass(customerPasswordDArrayList);
                break;
            case "7":
                Mainemenu.AdminMenu();
                break;
        }
        if (!input.equals(1) || !input.equals(2) || !input.equals(3) || !input.equals(4) || !input.equals(5) || !input.equals(6)) {
            Switch();
        }
        try {
            reader.close();
        } catch (IOException e) {
            e.getMessage();
        }
    }

    private static void WriteCustomers() {
        System.out.println("|______Registration module______|");
        try {
            CheckAllData.setReader();
            System.out.println("-->>First name: ");
            String firstName = reader.readLine();

            System.out.println("-->>Last name: ");
            String lastName = reader.readLine();

            System.out.println("-->>Email: ");
            String email = reader.readLine();

            System.out.println("-->>Contact number: ");
            String contactNo = reader.readLine();

            System.out.println("[1] Save: \n" + "[2] Cancel: ");
            String finalcheck = reader.readLine();

            if (finalcheck.equals("1")) {
                System.out.println("-->>Login for customer: ");
                String login1 = reader.readLine();

                System.out.println("-->>Password for customer: ");
                String password1 = reader.readLine();
                checkCustomerLogAndPass(customerPasswordDArrayList, login1);
                WritePassLog(customerPasswordDArrayList, login1, password1);
                WiteCustom(customerManagementDArraysList, firstName, lastName, email, contactNo);

            } else if (finalcheck.equals("2")) {
                Switch();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void checkCustomerLogAndPass(List<CustomerPasswordD> list, String login1) {
        CheckAllData.setReader();
        {
            while (customerLogPass.canRead()) {
                for (CustomerPasswordD cpd : list) {
                    if (login1.equals(cpd.getCustomerpass())) {
                        System.err.println("");
                        System.err.println("<===This login already taken===>");
                        System.err.print("");
                        WriteCustomers();
                    }
                }
                break;
            }
        }
    }

    private static void WiteCustom(List<CustomerManagementD> list, String firstName, String lastName, String email, String contactNo) {
        customerManagementDArraysList.add(new CustomerManagementD(customerID, firstName, lastName, email, contactNo));
        ObjectOutputStream outStream = null;
        try {
            outStream = new ObjectOutputStream(new FileOutputStream(customers));
            for (CustomerManagementD p : list) {
                outStream.writeObject(p);
            }
        } catch (IOException ioException) {
            System.err.println("Error opening file.");
        } finally {
            try {
                if (outStream != null) outStream.close();
                System.err.println("|______Customer was successfully saved______|\n   Press 'Enter' to continue...");
                String absentinput = reader.readLine();
                Switch();
            } catch (IOException ioException) {
                System.err.println("Error closing file.");
            }
        }
    }

    private static void DeleteCustomer(List<CustomerManagementD> list) {
        try {
            CheckAllData.setReader();
            {

                System.out.println("-->>Customer ID: ");
                String custID = reader.readLine();

                while (customers.canRead()) {
                    for (CustomerManagementD cmd : list) {
                        if (custID.equals(cmd.getCustomerID())) {
                            System.out.println("");
                            System.out.println("You want to delete ? " + "\n" + "Customer ID: " + cmd.getCustomerID() + " First Name: " + cmd.getFirstName() + " Last Name: " + cmd.getLastName() + " Email: " + cmd.getEmail() + " Contact number: " + cmd.getContactNo() + "\n" + "[1] Yes [2] No");
                            System.out.println("");
                            String deletecustomer = reader.readLine();
                            if (deletecustomer.equals("1")) {
                                System.out.println("");

                                setDeleteCustomer(custID);
                                setDeleteLogPass(custID);

                                ObjectOutputStream outStream = null;
                                try {
                                    outStream = new ObjectOutputStream(new FileOutputStream(customers));
                                    for (CustomerManagementD p : list) {
                                        outStream.writeObject(p);
                                    }
                                } catch (IOException ioException) {
                                    System.err.println("Error opening file.");
                                } finally {
                                    try {
                                        if (outStream != null) outStream.close();
                                        System.err.println("|______Customer was successfully deleted______|\n  " + " Press 'Enter' to continue...");
                                        String absentinput = reader.readLine();
                                        Switch();
                                    } catch (IOException ioException) {
                                        System.err.println("Error closing file.");
                                    }
                                }

                                System.err.println("Customer was deleted!\n" + "Press 'Enter' to continue...");
                                String deletecustomer1 = reader.readLine();
                                Switch();
                            } else if (deletecustomer.equals("2")) {
                                Switch();
                            }
                        }
                    }
                    break;
                }
                System.err.println("|=|=|=|=|=|=Customer was not found=|=|=|=|=|=|" + "\n" + "\n" + "\n");
            }
        } catch (IOException e) {
            e.getMessage();
        }
    }

    private static void EditCustomer(List<CustomerManagementD> list) {
        try {
            CheckAllData.setReader();
            {
                System.out.println("-->>Customer ID: ");
                String custID = reader.readLine();

                while (customers.canRead()) {
                    for (CustomerManagementD cmdEdit : list) {
                        if (custID.equals(cmdEdit.getCustomerID())) {
                            System.out.println("");
                            System.out.println("You want to Edit ? " + "\n" + "Customer ID: " + cmdEdit.getCustomerID() + " First Name: " + cmdEdit.getFirstName() + " Last Name: " + cmdEdit.getLastName() + " Email: " + cmdEdit.getEmail() + " Contact number: " + cmdEdit.getContactNo() + "\n" + "[1] Yes [2] No");
                            System.out.println("");
                            String deletecustomer = reader.readLine();

                            System.out.println("-->>First name: " + cmdEdit.getFirstName() + "\n -->Enter new: ");
                            String firstName = reader.readLine();

                            System.out.println("-->>Last name: " + cmdEdit.getLastName() + "\n -->Enter new: ");
                            String lastName = reader.readLine();

                            System.out.println("-->>Email: " + cmdEdit.getEmail() + "\n -->Enter new: ");
                            String email = reader.readLine();

                            System.out.println("-->>Contact number: " + cmdEdit.getContactNo() + "\n -->Enter new: ");
                            String contactNo = reader.readLine();

                            System.out.println("[1] Save: \n" + "[2] Cancel: ");
                            String finalcheck = reader.readLine();

                            if (finalcheck.equals("1")) {
                                // serialize collection of customers

                                customerManagementDArraysList.add(new CustomerManagementD(cmdEdit.getCustomerID(), firstName, lastName, email, contactNo));
                                setDeleteCustomer(custID);

                                ObjectOutputStream outStream = null;
                                try {
                                    outStream = new ObjectOutputStream(new FileOutputStream(customers));
                                    for (CustomerManagementD p : list) {
                                        outStream.writeObject(p);
                                    }
                                } catch (IOException ioException) {
                                    System.err.println("Error opening file.");
                                } finally {
                                    try {
                                        if (outStream != null) outStream.close();

                                        System.err.println("|______Information was successfully saved______|\n");
                                        System.err.println("|===You want change Username And Password?===| \n [1]Yes  [2]No");

                                        String changelogpass = reader.readLine();

                                        if (changelogpass.equals("1")) {

                                            EditCustomerLogPass(customerPasswordDArrayList, custID);

                                        } else if (changelogpass.equals("2") || changelogpass.isEmpty()) {

                                            Switch();
                                        }
                                    } catch (IOException ioException) {
                                        System.err.println("Error closing file.");
                                    }
                                }
                            } else if (finalcheck.equals("2")) {
                                Switch();
                            }
                        }
                    }
                    break;
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static void EditCustomerLogPass(List<CustomerPasswordD> list1, String custID) {
        try {
            CheckAllData.setReader();
            {
                while (customerLogPass.canRead()) {
                    for (CustomerPasswordD cpd : list1) {
                        if (custID.equals(cpd.getCustomerID())) {

                            System.out.println("-->Old username:" + cpd.getCustomerlog() + "\n -->Enter new: ");
                            String user = reader.readLine();

                            System.out.println("-->Old password:" + cpd.getCustomerpass() + "\n -->Enter new: ");
                            String password = reader.readLine();

                            // serialize collection of customers
                            customerPasswordDArrayList.add(new CustomerPasswordD(user, password, cpd.getCustomerID()));

                            setDeleteLogPass(custID);

                            ObjectOutputStream outStream1 = null;
                            try {
                                outStream1 = new ObjectOutputStream(new FileOutputStream(customerLogPass));
                                for (CustomerPasswordD p1 : list1) {
                                    outStream1.writeObject(p1);
                                }
                            } catch (IOException ioException) {
                                System.err.println("Error opening file.");
                            } finally {
                                try {
                                    if (outStream1 != null) outStream1.close();
                                    Switch();
                                } catch (IOException ioException) {
                                    System.err.println("Error closing file.");
                                }
                            }
                        }
                    }
                    break;
                }
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}
