package Menu;

import Data.CheckAllData;
import Data.RoutesD;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.*;

/**
 * Created by Bogdan
 */

public class RoutesManagement extends CheckAllData implements Serializable {

    public static void Switch() {
        System.out.println("\n|______Routes Management______|\n" + "[1] Load route \n" + "[2] Delete route \n" +"[3] View all routes  \n"+ "[4] Back to main menu \n");
        String input = null;
        try {
            input = reader.readLine();
        } catch (IOException e) {
            e.printStackTrace();
        }
        switch (input) {
            case "1":
                while (routes.canRead()) {
                    for (RoutesD RD : routesDArrayList) {
                        RouteID = RD.getPortID();
                        if (RouteID <= 23 || RouteID > 23) {
                            RouteID++;
                        }
                    }
                    break;
                }
                LoadRoute();
                break;
            case "2":
                DeleteRoute(routesDArrayList);
                break;
            case "3":
                ViewRoutes(routesDArrayList);
                break;
            case "4":
                Mainemenu.AdminMenu();
                break;
        }
        if (!input.equals(1) || !input.equals(2) || !input.equals(3) || !input.equals(4) || !input.equals(5)) {
            Switch();
        }
        try {
            reader.close();
        } catch (IOException e) {
            e.getMessage();
        }
    }


    private static void LoadRoute() {
        try {
            System.out.println("|______Register new port:______|");

            System.out.println("Name of port:");
            String portname = reader.readLine();

            System.out.println("Price:");
            String price = reader.readLine();
            int Price = Integer.parseInt(price);

            System.out.println("|___[1]Save___| \n|___[2]Cancel___|");
            String absen_input = reader.readLine();
            switch (absen_input) {
                case "1":
                    WriteRoute(routesDArrayList, portname, Price);
                case "2":
                    Switch();
                    break;
            }
            if (price.isEmpty() || portname.isEmpty()) {
                System.err.println("Error 'Empty input'.");
                Switch();
            }
        } catch (IOException e) {
            e.printStackTrace();
            Switch();
        }catch (NumberFormatException ex){
            Switch();
        }
    }

    private static void WriteRoute(ArrayList<RoutesD> list,String portname, int Price) {
        routesDArrayList.add(new RoutesD(RouteID, portname, Price));
        ObjectOutputStream outStream = null;
        try {
            outStream = new ObjectOutputStream(new FileOutputStream(routes));
            for (RoutesD p : list) {
                outStream.writeObject(p);
            }
        } catch (IOException ioException) {
            System.err.println("Error opening clients file.");
        } finally {
            try {
                if (outStream != null) outStream.close();
                System.err.println("|______Route was successfully saved______|\n   Press 'Enter' to continue...");
                String absentinput = reader.readLine();
                Switch();
            } catch (IOException ioException) {
                System.err.println("Error closing file.");
                Switch();
            }
        }
    }

    public static void Fixed_routes(){
        for (RoutesD RD1 : routesDArrayList1) {
            System.out.println(RD1.toString());
        }
    }

    private static void ViewRoutes(List<RoutesD> list) {
        Fixed_routes();
        while (routes.canRead()) {
            for (RoutesD RD : list) {
                System.out.println(RD.toString());
            }
            break;
        }
    }

    private static void DeleteRoute(ArrayList<RoutesD> list) {
        try {
            setReader();
            {
                System.out.println("-->>Route ID: ");
                String RouteID = reader.readLine();
                int routeID = Integer.parseInt(RouteID);
                while (routes.canRead()) {
                    for (RoutesD RDdelete : list) {
                        if (routeID == RDdelete.getPortID()) {
                            System.out.println("\nYou want to delete ? " + "\n" +"["+"ID: "+RDdelete.getPortID()+" Name of port: "+RDdelete.getNameOfport()+" Price: RM"+RDdelete.getPrice()+"]\n" + "[1] Yes [2] No\n");
                            String deleteclient = reader.readLine();
                            if (deleteclient.equals("1")) {
                                System.out.println("");

                                setDeleteClient(routeID);

                                System.err.println("|______Route was successfully deleted______|\n  " + " Press 'Enter' to continue...");
                                String absentinput = reader.readLine();
                                Switch();


                                System.err.println("Route was deleted!\n" + "Press 'Enter' to continue...");
                                String deleteclient1 = reader.readLine();
                                Switch();
                            } else if (deleteclient.equals("2")) {
                                Switch();
                            }
                        }
                    }
                    break;
                }
                System.err.println("|=|=|=|=|=|=Route was not found=|=|=|=|=|=|" + "\n"+ "\n");
            }
        } catch (IOException e) {
            e.getMessage();
        }
    }

    public static void setDeleteClient(int deleteClient) {
        //[Iterator]Fail Safe means: it won't fail. Strictly speaking,
        // there is no such thing in Java as a fail-safe iterator.
        // The correct term is "weakly consistent".
        Iterator itr = routesDArrayList.iterator();
        while (itr.hasNext()) {
            RoutesD element = (RoutesD) itr.next();
            if (element.getPortID() == deleteClient) {
                itr.remove();
                break;
            }
        }
    }
}

