package Menu;

import Data.ClientPasswordD;
import Data.ShippingCompaniesD;

import java.io.*;
import java.io.Serializable;
import java.io.FileOutputStream;
import java.io.ObjectOutputStream;

import java.util.List;

/**
 * Created by Bogdan
 */
public class AdminAndClientManagement extends ClientManagement implements Serializable {

    public static void Switch() {
        setReader();
        System.out.println("\n|______Client Management______|\n" +
                "[1] Register Client \n" + "[2] Delete Client \n" +
                "[3] Edit Client\n" + "[4] View all Shipping Companies  \n" +
                "[5] Search Shipping Company \n" + "[6] Search Client login and password \n" +
                "[7] Check leasing \n"+
                "[8] Back to main menu \n");
        String input = null;
        try {
            input = reader.readLine();
        } catch (IOException e) {
            e.printStackTrace();
        }
        switch (input) {
            case "1":
                /**
                 * Read ID from file and increment it
                 */
                while (clients.canRead()) {
                    for (ShippingCompaniesD scd : shippingCompaniesDArrayList) {
                        ClientID = Integer.parseInt(scd.getCompanyID());
                        if (ClientID <= 0 || ClientID > 0) {
                            ClientID++;
                        }
                    }
                    break;
                }
                clientID = Integer.toString(ClientID);
                InputDataClient();
                break;
            case "2":
                DeleteClient(shippingCompaniesDArrayList);
                break;
            case "3":
                EditClient(shippingCompaniesDArrayList);
                break;
            case "4":
                ViewClients(shippingCompaniesDArrayList);
                break;
            case "5":
                ViewCompany(shippingCompaniesDArrayList);
                break;
            case "6":
                ViewClientLogAndPass(clientPasswordDArrayList);
                break;
            case "7":
                checkleasing(leasingDArrayList);
                break;
            case "8":
                Mainemenu.AdminMenu();
                break;

        }
        if (!input.equals(1) || !input.equals(2) || !input.equals(3) || !input.equals(4) || !input.equals(5) || !input.equals(6) || !input.equals(7) || !input.equals(8)) {
            Switch();
        }
        try {
            reader.close();
        } catch (IOException e) {
            e.getMessage();
        }
    }



    public static void InputDataClient() {
        System.out.println("\n|______Registration module______|");
        try {
            setReader();
            System.out.println("-->>Company name: ");
            String companyName = reader.readLine();

            System.out.println("-->>Company email: ");
            String companyemail = reader.readLine();

            System.out.println("-->>Contact number: ");
            String contactNo = reader.readLine();

            System.out.print("\n|______Select type of ship_____|" +
                    " \n" +
                    "[1] Containers\n" +
                    "[2] Barge\n" +
                    "[3] Tankers\n" +
                    "[4] Tugboats\n" +
                    "[5] Cargo\n" +
                    "[6] Cruises\n");
            String select = reader.readLine();
            switch (select){
                case "1":
                    Ship = "Containers";
                    Shippingcosts =  5000;
                    SwitchLising(Shippingcosts,Ship,companyName,companyemail,contactNo);
                    break;
                case "2":
                    Ship = "Barge";
                    Shippingcosts =  15000;
                    SwitchLising(Shippingcosts,Ship,companyName,companyemail,contactNo);
                    break;
                case "3":
                    Ship = "Tankers";
                    Shippingcosts =  20000;
                    SwitchLising(Shippingcosts,Ship,companyName,companyemail,contactNo);
                    break;
                case "4":
                    Ship = "Tugboats";
                    Shippingcosts =  30000;
                    SwitchLising(Shippingcosts,Ship,companyName,companyemail,contactNo);
                    break;
                case "5":
                    Ship = "Cargo";
                    Shippingcosts =  17000;
                    SwitchLising(Shippingcosts,Ship,companyName,companyemail,contactNo);
                    break;
                case "6":
                    Ship = "Cruises";
                    Shippingcosts =  40000;
                    SwitchLising(Shippingcosts,Ship,companyName,companyemail,contactNo);
                    break;
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void SwitchLising(int finalprice,String Ship,String companyName, String companyemail,String contactNo) {
        try {
            System.out.print("\n|______Select type of leasing______| \n" +
                    "[1] Contract hire: (10% per year)\n" +
                    "[2] Operating leasing(40% per year)\n");
            String select = reader.readLine();
            switch (select){
                case "1":
                    typeofleasing = "Contract hire";
                    ContractHire(finalprice,Ship,companyName,companyemail,contactNo);
                    break;
                case "2":
                    typeofleasing = "Operating leasing";
                    OperatingLeasing(finalprice,Ship,companyName,companyemail,contactNo);
                    break;
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    private static void DeleteClient(List<ShippingCompaniesD> list) {
        try {
            setReader();
            {

                System.out.println("-->>Client ID: ");
                String ClientID = reader.readLine();

                while (clients.canRead()) {
                    for (ShippingCompaniesD scd : list) {
                        if (ClientID.equals(scd.getCompanyID())) {
                            System.out.println("");
                            System.out.println("You want to delete ? " + "\n" + "Client ID: " + scd.getCompanyID() + " Client Name: " + scd.getCompanyName() + " Email: " + scd.getCompanyEmail() + " Contact number: " + scd.getCompanyContNo() + "[1] Yes [2] No");
                            System.out.println("");
                            String deleteclient = reader.readLine();
                            if (deleteclient.equals("1")) {
                                System.out.println("");

                                setDeleteClient(ClientID);
                                setDeleteClientLogPass(ClientID);
                                setDeleteClientLeasing(ClientID);


                                System.err.println("|______Client was successfully deleted______|\n  " + " Press 'Enter' to continue...");
                                String absentinput = reader.readLine();
                                Switch();


                                System.err.println("Client was deleted!\n" + "Press 'Enter' to continue...");
                                String deleteclient1 = reader.readLine();
                                Switch();
                            } else if (deleteclient.equals("2")) {
                                Switch();
                            }
                        }
                    }
                    break;
                }
                System.err.println("|=|=|=|=|=|=Client was not found=|=|=|=|=|=|" + "\n" + "\n");
            }
        } catch (IOException e) {
            e.getMessage();
        }
    }

    private static void EditClient(List<ShippingCompaniesD> list) {
        try {
            setReader();
            {
                System.out.println("-->>Customer ID: ");
                String ClientID = reader.readLine();

                while (clients.canRead()) {
                    for (ShippingCompaniesD scdEdit : list) {
                        if (ClientID.equals(scdEdit.getCompanyID())) {
                            System.out.println(""+"\n"+"You want to Edit ? " + "\n" + "Client ID: " + scdEdit.getCompanyID() + " Company Name: " + scdEdit.getCompanyName() + " Email: " + scdEdit.getCompanyEmail() + " Contact number: " + scdEdit.getCompanyContNo() + "\n" + "[1] Yes [2] No"+"\n"+"");
                            String deleteclient= reader.readLine();

                            System.out.println("-->>Company Name: " + scdEdit.getCompanyName() + "\n -->Enter new: ");
                            String ComapnyName = reader.readLine();

                            System.out.println("-->>Email: " + scdEdit.getCompanyEmail() + "\n -->Enter new: ");
                            String email = reader.readLine();

                            System.out.println("-->>Contact number: " + scdEdit.getCompanyContNo() + "\n -->Enter new: ");
                            String contactNo = reader.readLine();

                            System.out.println("[1] Save: \n" + "[2] Cancel: ");
                            String finalcheck = reader.readLine();

                            if (finalcheck.equals("1")) {
                                // serialize collection of customers

                                shippingCompaniesDArrayList.add(new ShippingCompaniesD(scdEdit.getCompanyID(), ComapnyName,email, contactNo, Ship));
                                setDeleteClient(ClientID);

                                ObjectOutputStream outStream = null;
                                try {
                                    outStream = new ObjectOutputStream(new FileOutputStream(clients));
                                    for (ShippingCompaniesD p : list) {
                                        outStream.writeObject(p);
                                    }
                                } catch (IOException ioException) {
                                    System.err.println("Error opening file.");
                                } finally {
                                    try {
                                        if (outStream != null) outStream.close();

                                        System.err.println("|______Information was successfully saved______|\n");
                                        System.err.println("|===You want change Username And Password?===| \n [1]Yes  [2]No");

                                        String changelogpass = reader.readLine();

                                        if (changelogpass.equals("1")) {

                                            EditClientLogPass(clientPasswordDArrayList, ClientID);

                                        } else if (changelogpass.equals("2") || changelogpass.isEmpty()) {

                                            Switch();
                                        }
                                    } catch (IOException ioException) {
                                        System.err.println("Error closing file.");
                                    }
                                }
                            } else if (finalcheck.equals("2")) {
                                Switch();
                            }
                        }
                    }
                    break;
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static void EditClientLogPass(List<ClientPasswordD> list1, String ClientID) {
        try {
            setReader();
            {
                while (clientsLogPass.canRead()) {
                    for (ClientPasswordD cpd: list1) {
                        if (ClientID.equals(cpd.getClientID())) {

                            System.out.println("-->Old username:" + cpd.getClientlog() + "\n -->Enter new: ");
                            String user = reader.readLine();

                            System.out.println("-->Old password:" + cpd.getClientpass() + "\n -->Enter new: ");
                            String password = reader.readLine();

                            // serialize collection of customers
                            clientPasswordDArrayList.add(new ClientPasswordD(user, password, cpd.getClientID()));

                            setDeleteClientLogPass(ClientID);

                            ObjectOutputStream Stream = null;
                            try {
                                Stream = new ObjectOutputStream(new FileOutputStream(clientsLogPass));
                                for (ClientPasswordD p1 : list1) {
                                    Stream.writeObject(p1);
                                }
                            } catch (IOException ioException) {
                                System.err.println("Error opening file.");
                            } finally {
                                try {
                                    if (Stream != null) Stream.close();
                                    Switch();
                                } catch (IOException ioException) {
                                    System.err.println("Error closing file.");
                                }
                            }
                        }
                    }
                    break;
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
