package Exiting;

import java.util.Scanner;

/**
 * Created by Bogdan on 12/25/2016.
 */
public class Exit {
    public static void exiting() {
        Scanner input = new Scanner(System.in);
        String key;
        System.out.println("____---Press 'Enter' to Exit---____");
        key = input.nextLine();
        System.exit(0);
    }
}
