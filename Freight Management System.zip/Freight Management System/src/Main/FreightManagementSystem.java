package Main; /**
 * Created by Bogdan
 */

import login.Login;
import Data.CheckAllData;


public class FreightManagementSystem extends CheckAllData {

    public static void main(String[] args){
        CustomercheckDB();
        ClientrcheckDB();
        RoutesDB(routesDArrayList1);
        Login.checkInput();

    }

}
