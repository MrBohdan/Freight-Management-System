package Data;

import java.io.Serializable;


/**
 * Created by Bogdan
 */
public class ClientPasswordD implements Serializable,Comparable<ClientPasswordD>{
    public String clientID;
    public String clientlog;
    public String clientpass;

    public ClientPasswordD(String clientlog, String clientpass,String clientID) {
        this.setClientlog(clientlog);
        this.setClientpass(clientpass);
        this.setClientID(clientID);

    }
    public String getClientlog() {
        return this.clientlog;
    }

    public String getClientpass() {
        return this.clientpass;
    }

    public String getClientID() {
        return this.clientID;
    }

    public void setClientlog(String clientlog) {
        this.clientlog = clientlog;
    }

    public void setClientpass(String clientpass) {
        this.clientpass = clientpass;
    }

    public void setClientID(String clientID) {
        this.clientID = clientID;
    }

    public int compareTo(ClientPasswordD list){
        return this.clientID.compareTo(list.getClientID());}
    @Override
    public String toString(){
        return "["+"Customer ID: "+clientID +" Login: " + clientlog + " Password: " + clientpass+"]";
    }
}
