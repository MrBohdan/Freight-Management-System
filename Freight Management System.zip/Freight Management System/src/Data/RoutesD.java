package Data;

import java.io.Serializable;


/**
 * Created by Bogdan
 */
public class RoutesD implements Serializable{
    public int portID;
    public String nameOfport;
    public int price;
    public RoutesD(int portID,String nameOfport,int price){
        this.setPortID(portID);
        this.setNameOfport(nameOfport);
        this.setPrice(price);

    }

    public void setPortID(int portID) {
        this.portID = portID;
    }

    public void setNameOfport(String nameOfport) {
        this.nameOfport = nameOfport;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public int getPortID(){return this.portID;}

    public String getNameOfport(){return this.nameOfport;}

    public int getPrice(){return this.price;}

    @Override
    public boolean equals(Object o) {
        if (!(o instanceof RoutesD)) {
            return false;
        }

        // id must be the same for two Routes to be equal
        RoutesD p = (RoutesD) o;
        if (this.portID == p.getPortID()) {
            return true;
        }
        return false;
    }

    @Override
    public int hashCode() {
        return this.portID;
    }
    @Override
    public String toString(){
        return "["+"ID: "+portID+" Name of port: "+nameOfport+" Price: RM"+price+"]"+ "\n";
    }


}
