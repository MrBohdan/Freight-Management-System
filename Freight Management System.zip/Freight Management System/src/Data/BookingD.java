package Data;

import java.io.Serializable;
/**
 * Created by Bogdan
 */
public class BookingD implements Serializable{

    public int bookingID;
    public String customerID;
    public String bookingdate;
    public String type_of_cargo;
    public String port1;
    public String port2;
    public int total_price;
    public BookingD(){

    }
    public BookingD(int bookingID,String customerID,String bookingdate,String type_of_cargo,
                   String port1,String port2,int total_price) {
        this.setBookingID(bookingID);
        this.setCustomerID(customerID);
        this.setBookingDate(bookingdate);
        this.setType_of_cargo(type_of_cargo);
        this.setPort1(port1);
        this.setPort2(port2);
        this.setTotal_Price(total_price);
    }

    public void setBookingID(int bookingID) {
        this.bookingID = bookingID;
    }

    public void setCustomerID(String customerID) {
        this.customerID = customerID;
    }

    public void setBookingDate(String bookingdate) {
        this.bookingdate = bookingdate;
    }

    public void setPort1(String port1) {
        this.port1 = port1;
    }

    public void setPort2(String port2) {
        this.port2 = port2;
    }

    public void setTotal_Price(int total_Price) {
        this.total_price = total_Price;
    }

    public void setType_of_cargo(String type_of_cargo) {
        this.type_of_cargo = type_of_cargo;
    }

    public int getBookingID() {
        return this.bookingID;
    }

    public String getCustomerID() {
        return this.customerID;
    }

    public String getBookingdate() {
        return this.bookingdate;
    }

    public String getType_of_cargo() {
        return this.type_of_cargo;
    }

    public String getPort1() {
        return this.port1;
    }

    public String getPort2() {
        return this.port2;
    }

    public int getTotal_Price() {
        return this.total_price;
    }

    @Override
    public String toString(){
        return "["+" Booking ID: "+bookingID+" Customer ID: " + customerID +" Booking date: " +  bookingdate + " Direction: "+port1 +" To " + port2 + " Total price: RM" +total_price+"]";
    }



}