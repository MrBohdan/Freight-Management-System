package Data;

import java.io.*;
import java.util.ArrayList;

/**
 * Created by Bogdan
 */
public class ShippingCompaniesD implements Serializable,Comparable<ShippingCompaniesD> {
    public String companyID;
    public String companyName;
    public String companyEmail;
    public String companyContNo;
    public String typeofship;
    public ShippingCompaniesD(String companyID, String companyName,String companyEmail, String companyContNo, String typeofship) {
        this.setCompanyID(companyID);
        this.setCompanyName(companyName);
        this.setCompanyEmail(companyEmail);
        this.setCompanyContNo(companyContNo);
        this.setTypeOfShip(typeofship);
    }

    public void setCompanyID(String companyID) {
        this.companyID = companyID;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public void setCompanyEmail(String companyEmail) {
        this.companyEmail = companyEmail;
    }

    public void setCompanyContNo(String companyContNo) {
        this.companyContNo = companyContNo;
    }

    public void setTypeOfShip(String typeofship) {
        this.typeofship = typeofship;
    }

    public  String getCompanyID() {
        return this.companyID;
    }

    public String getCompanyName() {
        return this.companyName;
    }

    public String getCompanyEmail() {
        return this.companyEmail;
    }

    public String getCompanyContNo() {
        return this.companyContNo;
    }

    public String getTypeOfShip() {
        return this.typeofship;
    }

    public int compareTo(ShippingCompaniesD list){
        return this.companyID.compareTo(list.getCompanyID());}

    @Override
    public String toString(){
        return "["+"Company ID: "+companyID +" Name: " + companyName + " Email: " + companyEmail+" Company number: "+companyContNo+" Type of Ship: "+ typeofship +"]";
    }



}