package Data;

import java.io.Serializable;
import java.util.ArrayList;

/**
 * Created by Bogdan
 */
public class LeasingD implements Serializable,Comparable<LeasingD>{
    public String companyID;
    public String companyName;
    public String typeofleasing;
    public int finalprice;

    public LeasingD(String companyID, String companyName, String typeofleasing,int finalprice) {
        this.setCompanyID(companyID);
        this.setCompanyName(companyName);
        this.setTypeOfLeasing(typeofleasing);
        this.setFinalprice(finalprice);
    }

    public void setCompanyID(String companyID) {
        this.companyID = companyID;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }


    public void setTypeOfLeasing(String typeofleasing) {
        this.typeofleasing = typeofleasing;
    }

    public void setFinalprice(int finalprice) {
        this.finalprice = finalprice;
    }

    public  String getCompanyID() {
        return this.companyID;
    }

    public String getCompanyName() {
        return this.companyName;
    }

    public String getTypeOfLeasing() {
        return this.typeofleasing;
    }

    public int getFinalprice() {
        return this.finalprice;
    }

    public int compareTo(LeasingD list){
        return this.companyID.compareTo(list.getCompanyID());}

    @Override
    public String toString(){
        return "["+"Company ID: "+companyID +" Name: " + companyName + " Type of Leasing: "+typeofleasing+" Final price: RM"+finalprice+"]";
    }


}
