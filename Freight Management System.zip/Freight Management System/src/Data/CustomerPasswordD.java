package Data;

import java.io.Serializable;

/**
 * Created by Bogdan
 */
public class CustomerPasswordD implements Serializable,Comparable<CustomerPasswordD> {
    public String customerID;
    public String customerlog;
    public String customerpass;

    public CustomerPasswordD(String customerlog, String customerpass,String customerID) {
        this.setCustomerlog(customerlog);
        this.setCustomerpass(customerpass);
        this.setCustomerID(customerID);

    }
    public String getCustomerlog() {
        return this.customerlog;
    }

    public String getCustomerpass() {
        return this.customerpass;
    }

    public String getCustomerID() {
        return this.customerID;
    }

    public void setCustomerlog(String customerlog) {
        this.customerlog = customerlog;
    }

    public void setCustomerpass(String customerpass) {
        this.customerpass = customerpass;
    }

    public void setCustomerID(String customerID) {
        this.customerID = customerID;
    }
    public int compareTo(CustomerPasswordD list){
        return this.customerID.compareTo(list.getCustomerID());}
    @Override
    public String toString(){
        return "["+"Customer ID: "+customerID +" Login: " + customerlog + " Password: " + customerpass+"]";
    }
}