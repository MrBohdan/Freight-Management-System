package Data;

import java.io.*;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;


/**
 * Created by Bogdan
 */
public class CheckAllData {
    /**
     * FOR CUSTOMERS
     */
    public static BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));

    public static File customers = new File("CustomerManagement.txt");
    public static File customerLogPass = new File("CustomerLogPass.txt");

    public static ArrayList<CustomerManagementD> customerManagementDArraysList = new ArrayList<>();
    public static ArrayList<CustomerPasswordD> customerPasswordDArrayList = new ArrayList<>();

    public static int cusID = 1;
    public static String customerID;
    /**
     * FOR CLIENTS / COMPANY's / ROUTES / BOOKING
     */
    public static File clients = new File("ClientManagement.txt");
    public static File clientsLogPass = new File("ClientLogPass.txt");
    public static File leasing = new File("Leasing.txt");


    public static ArrayList<ShippingCompaniesD> shippingCompaniesDArrayList = new ArrayList<>();
    public static ArrayList<ClientPasswordD>  clientPasswordDArrayList = new ArrayList<>();
    public static ArrayList<LeasingD>  leasingDArrayList = new ArrayList<>();

    public static String typeofleasing;
    public static int ClientID = 1;
    public static String Ship;
    public static int Shippingcosts;
    public static String clientID;
    /**
     * FOR ROUTES / BOOKING
     */
    public static File booking = new File("Booking.txt");
    public static File routes = new File("Freight Routes.txt");
    public static File fixed_routes = new File("Fixed Routes.txt");

    public static ArrayList<BookingD>  bookingDArrayList = new ArrayList<>();
    public static ArrayList<RoutesD> routesDArrayList = new ArrayList<>();
    public static Set<RoutesD> routesDArrayList1 = new HashSet<RoutesD>();

    public static int RouteID = 24;
    public static int bookingID = 1;
    // so the first time the boolean will be false, and the code will
    // be executed, and the other times the boolean will be true,
    // and the code will be skipped
    public static boolean check = false;
    public static void CustomercheckDB() {
        if (check == false) {
            try {
                //Customers info
                FileInputStream fis1 = new FileInputStream(customers);
                ObjectInputStream oos1 = new ObjectInputStream(fis1);
                //Customers Login and Passwords
                FileInputStream fis2 = new FileInputStream(customerLogPass);
                ObjectInputStream oos2 = new ObjectInputStream(fis2);
                while (true) {

                    //check Customers info
                    CustomerManagementD cmd1 = (CustomerManagementD) oos1.readObject();
                    customerManagementDArraysList.add(cmd1);

                    //check customers passwords and login(+ID)
                    CustomerPasswordD cpd = (CustomerPasswordD) oos2.readObject();
                    customerPasswordDArrayList.add(cpd);

                }
            } catch (ClassNotFoundException | IOException e) {
            }
        }
        check = true;
    }
    public static boolean check1 = false;
    public  static  void   ClientrcheckDB(){
        if (check1 == false) {
            try {
        FileInputStream FIS1 = new FileInputStream(clients);
        ObjectInputStream OOS1 = new ObjectInputStream(FIS1);
        //Client Login and Passwords
        FileInputStream FIS2 = new FileInputStream(clientsLogPass);
        ObjectInputStream OOS2 = new ObjectInputStream(FIS2);
        //Leasing
        FileInputStream FIS3 = new FileInputStream(leasing);
        ObjectInputStream OOS3 = new ObjectInputStream(FIS3);

        FileInputStream FIS4 = new FileInputStream(booking);
        ObjectInputStream OOS4 = new ObjectInputStream(FIS4);
        while (true){

            ShippingCompaniesD SCD = (ShippingCompaniesD) OOS1.readObject();
            shippingCompaniesDArrayList.add(SCD);

            //Check Client passwords and login(+ID)
            ClientPasswordD client = (ClientPasswordD) OOS2.readObject();
            clientPasswordDArrayList.add(client);

            //Leasing
            LeasingD leasing = (LeasingD) OOS3.readObject();
            leasingDArrayList.add(leasing);
            // booking
            BookingD bookingD = (BookingD) OOS4.readObject();
            bookingDArrayList.add(bookingD);
        }
            } catch (IOException | ClassNotFoundException e) {
            }
        }
        check1 = true;
    }
    public static boolean check2 = false;
    public  static  void   RoutesDB(Set<RoutesD> list){
        if (check2 == false) {
            try {
                FileInputStream FIS1 = new FileInputStream(routes);
                ObjectInputStream OOS1 = new ObjectInputStream(FIS1);
                while (true){
                    RoutesD RD = (RoutesD) OOS1.readObject();
                    routesDArrayList.add(RD);
                    RoutesD routesD1 = new RoutesD(1, "New York", 300);
                    RoutesD routesD2 = new RoutesD(2, "Yonkers", 350);
                    RoutesD routesD3 = new RoutesD(3, "Tarryto", 400);
                    RoutesD routesD4 = new RoutesD(4, "Tarrytown", 450);
                    RoutesD routesD5 = new RoutesD(5, "Nyack", 500);
                    RoutesD routesD6 = new RoutesD(6, "Ossinina", 550);
                    RoutesD routesD7 = new RoutesD(7, "Haverstraw", 600);
                    RoutesD routesD8 = new RoutesD(8, "Peekskill", 650);
                    RoutesD routesD9 = new RoutesD(9, "West Point", 700);
                    RoutesD routesD10 = new RoutesD(10, "Newbrugh", 750);
                    RoutesD routesD11 = new RoutesD(11, "Hyde Park", 800);
                    RoutesD routesD12 = new RoutesD(12, "Kingston", 850);
                    RoutesD routesD13 = new RoutesD(13, "Saugerties", 900);
                    RoutesD routesD14 = new RoutesD(14, "Catskill", 950);
                    RoutesD routesD15 = new RoutesD(15, "Hudson", 1000);
                    RoutesD routesD16 = new RoutesD(16, "Athens", 1050);
                    RoutesD routesD17 = new RoutesD(17, "Coxsacckie", 1100);
                    RoutesD routesD18 = new RoutesD(18, "Coeymans", 1150);
                    RoutesD routesD19 = new RoutesD(19, "Albany", 1200);
                    RoutesD routesD20 = new RoutesD(20, "Rensselaer", 1250);
                    RoutesD routesD21 = new RoutesD(21, "Troy", 1300);
                    RoutesD routesD22 = new RoutesD(22, "Warevliet", 1350);
                    RoutesD routesD23 = new RoutesD(23, "Troy Lok", 1400);
                    routesDArrayList1.add(routesD1);
                    routesDArrayList1.add(routesD2);
                    routesDArrayList1.add(routesD3);
                    routesDArrayList1.add(routesD4);
                    routesDArrayList1.add(routesD5);
                    routesDArrayList1.add(routesD6);
                    routesDArrayList1.add(routesD7);
                    routesDArrayList1.add(routesD8);
                    routesDArrayList1.add(routesD9);
                    routesDArrayList1.add(routesD10);
                    routesDArrayList1.add(routesD11);
                    routesDArrayList1.add(routesD12);
                    routesDArrayList1.add(routesD13);
                    routesDArrayList1.add(routesD14);
                    routesDArrayList1.add(routesD15);
                    routesDArrayList1.add(routesD16);
                    routesDArrayList1.add(routesD17);
                    routesDArrayList1.add(routesD18);
                    routesDArrayList1.add(routesD19);
                    routesDArrayList1.add(routesD20);
                    routesDArrayList1.add(routesD21);
                    routesDArrayList1.add(routesD22);
                    routesDArrayList1.add(routesD23);
                    ObjectOutputStream outStream = null;
                    try {
                        outStream = new ObjectOutputStream(new FileOutputStream(fixed_routes));
                        for (RoutesD p : list) {
                            outStream.writeObject(p);
                        }
                    } catch (IOException ioException) {
                    } finally {
                        try {
                            if (outStream != null) outStream.close();
                        } catch (IOException ioException) {
                            ioException.getMessage();
                        }
                    }
                }
            } catch (IOException | ClassNotFoundException e) {
            }
        }
        check2 = true;
    }
    public static void setReader(){
        try {

            FileInputStream fis1 = new FileInputStream(customers);
            ObjectInputStream oos1 = new ObjectInputStream(fis1);

            FileInputStream fis2 = new FileInputStream(customerLogPass);
            ObjectInputStream oos2 = new ObjectInputStream(fis2);

            FileInputStream FIS3 = new FileInputStream(clients);
            ObjectInputStream OOS3 = new ObjectInputStream(FIS3);

            FileInputStream FIS4= new FileInputStream(clientsLogPass);
            ObjectInputStream OOS4 = new ObjectInputStream(FIS4);

            FileInputStream FIS5 = new FileInputStream(leasing);
            ObjectInputStream OOS5 = new ObjectInputStream(FIS5);

            FileInputStream FIS6 = new FileInputStream(routes);
            ObjectInputStream OOS6 = new ObjectInputStream(FIS6);

            ArrayList<CustomerManagementD> customerManagementDArraysList = new ArrayList<>();
            ArrayList<CustomerPasswordD> customerPasswordDArrayList = new ArrayList<>();

            ArrayList<ShippingCompaniesD> shippingCompaniesDArrayList = new ArrayList<>();
            ArrayList<ClientPasswordD>  clientPasswordDArrayList = new ArrayList<>();
            ArrayList<LeasingD>  leasingDArrayList = new ArrayList<>();

            ArrayList<RoutesD>  routesDArrayList = new ArrayList<>();

            while (true) {
                CustomerPasswordD cpd = (CustomerPasswordD) oos2.readObject();
                customerPasswordDArrayList.add(cpd);

                CustomerManagementD cmd = (CustomerManagementD) oos1.readObject();
                customerManagementDArraysList.add(cmd);

                ShippingCompaniesD scd = (ShippingCompaniesD) OOS3.readObject();
                shippingCompaniesDArrayList.add(scd);

                ClientPasswordD clientpd = (ClientPasswordD) OOS4.readObject();
                clientPasswordDArrayList.add(clientpd);

                LeasingD leasing = (LeasingD) OOS5.readObject();
                leasingDArrayList.add(leasing);

                RoutesD routesD = (RoutesD) OOS6.readObject();
                routesDArrayList.add(routesD);

            }
        } catch (IOException e) {
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

}
