package Data;

/**
 * Created by Bogdan
 */
import java.io.*;
import java.util.ArrayList;

public class CustomerManagementD implements Serializable,Comparable<CustomerManagementD>  {
    public String customerID;
    public String firstName;
    public String lastName;
    public String email;
    public String contactNo;

    public CustomerManagementD(String customerID, String firstName, String lastName, String email,
                               String contactNo) {
        this.setCustomerID(customerID);
        this.setFirstName(firstName);
        this.setLastName(lastName);
        this.setEmail(email);
        this.setContactNo(contactNo);
    }

    public String getCustomerID() {
        return this.customerID;
    }

    public void setCustomerID(String customerID) {
        this.customerID = customerID;
    }

    public String getFirstName() {
        return this.firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return this.lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getEmail() {
        return this.email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getContactNo() {
        return this.contactNo;
    }

    public void setContactNo(String contactNo) {
        this.contactNo = contactNo;
    }

    public int compareTo(CustomerManagementD list){
        return this.customerID.compareTo(list.getCustomerID());}

    @Override
    public String toString(){
        return "["+"Customer ID: " + customerID + " First Name: " + firstName +
                " Last Name: " + lastName + " Email: " +  email + " Contact number: "+contactNo +"]";
    }
}
